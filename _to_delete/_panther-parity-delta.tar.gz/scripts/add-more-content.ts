/**
 * Adds MORE sample gallery photos, placeholder testimonials, placeholder
 * service plan tiers, and the Service Plans / Reviews page heading & intro
 * text to a database that's already been seeded (npm run seed only seeds a
 * collection the first time — it intentionally never touches a collection
 * that already has items, so it won't add more later). This script is
 * separate and additive: safe to run as many times as you like, it checks
 * for each item by a stable key (title, name, or pageKey) before inserting
 * so nothing is ever duplicated.
 *
 * Service plan pricing is never invented — every plan's priceLabel defaults
 * to "Contact for Pricing" (free text, editable from the admin Service Plans
 * page) until real pricing is confirmed.
 *
 * Use this if the site feels a little sparse after the initial seed and you
 * want more sample content to fill it out while you gather real photos,
 * reviews, and pricing.
 *
 * Usage:
 *   npm run seed:more
 */
import path from "node:path";
import fs from "node:fs";
import dotenv from "dotenv";
import mongoose from "mongoose";
import { GridFSBucket } from "mongodb";

dotenv.config({ path: ".env.local" });
dotenv.config();

import { Media } from "../src/models/Media";
import { GalleryItem } from "../src/models/GalleryItem";
import { Testimonial } from "../src/models/Testimonial";
import { ServicePlan } from "../src/models/ServicePlan";
import { Page } from "../src/models/Page";
import { Navigation } from "../src/models/Navigation";
import { Service } from "../src/models/Service";

const MONGODB_URI = process.env.MONGODB_URI;
const SEED_ASSETS_DIR = path.join(__dirname, "..", "seed-assets");

async function uploadLocalImage(filename: string, alt: string): Promise<mongoose.Types.ObjectId> {
  const existing = await Media.findOne({ filename });
  if (existing) return existing._id;

  const filePath = path.join(SEED_ASSETS_DIR, filename);
  const buffer = fs.readFileSync(filePath);
  const db = mongoose.connection.db;
  if (!db) throw new Error("No database connection");
  const bucket = new GridFSBucket(db, { bucketName: "media" });

  const gridfsId = await new Promise<mongoose.Types.ObjectId>((resolve, reject) => {
    const uploadStream = bucket.openUploadStream(filename, {
      metadata: { contentType: "image/jpeg" },
    });
    uploadStream.on("error", reject);
    uploadStream.on("finish", () => resolve(uploadStream.id as mongoose.Types.ObjectId));
    uploadStream.end(buffer);
  });

  const media = await Media.create({
    gridfsId,
    filename,
    mimeType: "image/jpeg",
    size: buffer.length,
    alt,
    uploadedBy: "seed-script",
  });

  return media._id;
}

async function addGalleryItemIfMissing(item: {
  title: string;
  caption: string;
  category: string;
  imageMediaId: mongoose.Types.ObjectId;
  order: number;
  featured: boolean;
}) {
  const existing = await GalleryItem.findOne({ title: item.title });
  if (existing) {
    console.log(`Gallery item "${item.title}" already exists, skipping.`);
    return;
  }
  await GalleryItem.create({ ...item, active: true });
  console.log(`Added gallery item "${item.title}".`);
}

async function addTestimonialIfMissing(marker: string, data: {
  customerName: string;
  testimonialText: string;
  rating: number;
  order: number;
}) {
  // Placeholder testimonials all share generic text, so we key uniqueness
  // off the `order` slot rather than the text itself.
  const existing = await Testimonial.findOne({ order: data.order, isPlaceholder: true });
  if (existing) {
    console.log(`Placeholder testimonial #${data.order} already exists, skipping.`);
    return;
  }
  await Testimonial.create({
    ...data,
    location: "",
    isPlaceholder: true,
    featured: data.order < 3,
    active: true,
  });
  console.log(`Added placeholder testimonial #${data.order}.`);
}

async function addServicePlanIfMissing(plan: {
  name: string;
  tagline: string;
  frequency: string;
  features: string[];
  priceLabel: string;
  highlighted: boolean;
  order: number;
}) {
  const existing = await ServicePlan.findOne({ name: plan.name });
  if (existing) {
    console.log(`Service plan "${plan.name}" already exists, skipping.`);
    return;
  }
  await ServicePlan.create({ ...plan, active: true });
  console.log(`Added service plan "${plan.name}".`);
}

async function upsertPageIfMissing(
  pageKey: string,
  content: Record<string, unknown>,
  seo: { title: string; metaDescription: string }
) {
  const existing = await Page.findOne({ pageKey });
  if (existing) {
    console.log(`Page "${pageKey}" already exists, skipping.`);
    return;
  }
  await Page.create({
    pageKey,
    content,
    seo: { ...seo, ogTitle: seo.title, ogDescription: seo.metaDescription, canonicalUrl: "" },
    status: "published",
  });
  console.log(`Seeded page content for "${pageKey}".`);
}

async function addServiceIfMissing(service: {
  name: string;
  slug: string;
  shortDescription: string;
  description: string;
  icon: string;
  order: number;
}) {
  const existing = await Service.findOne({ slug: service.slug });
  if (existing) {
    console.log(`Service "${service.name}" already exists, skipping.`);
    return;
  }
  await Service.create({ ...service, featured: false, active: true });
  console.log(`Added service "${service.name}".`);
}

async function addNavItemIfMissing(item: { label: string; href: string }) {
  const nav = await Navigation.findOne();
  if (!nav) {
    console.log(`No navigation document exists yet, skipping nav item "${item.label}".`);
    return;
  }
  const exists = (nav.items ?? []).some((i: { href: string }) => i.href === item.href);
  if (exists) {
    console.log(`Nav item "${item.label}" already exists, skipping.`);
    return;
  }
  const nextOrder = (nav.items ?? []).length;
  nav.items.push({ label: item.label, href: item.href, order: nextOrder, visible: true });
  await nav.save();
  console.log(`Added nav item "${item.label}" -> ${item.href}.`);
}

async function main() {
  if (!MONGODB_URI) {
    console.error("MONGODB_URI is not set. Add it to .env.local before running this.");
    process.exit(1);
  }

  await mongoose.connect(MONGODB_URI);
  console.log("Connected to MongoDB.\n");

  const houseSiding = await uploadLocalImage("house-siding-new.jpg", "House exterior with clean vinyl siding");
  const roofBeachHouse = await uploadLocalImage("roof-beach-house.jpg", "Two-story house with clean asphalt shingle roof");
  const windowSiding = await uploadLocalImage("window-detail-siding.jpg", "Close-up of clean exterior windows and siding");
  const windowBay = await uploadLocalImage("window-detail-bay.jpg", "Close-up of a clean bay window with stone siding");

  const existingGalleryCount = await GalleryItem.countDocuments();
  const nextOrder = existingGalleryCount; // append after whatever's already there

  await addGalleryItemIfMissing({
    title: "Siding Wash — Split-Level Home",
    caption: "Soft-wash siding cleaning on a split-level house",
    category: "Houses",
    imageMediaId: houseSiding,
    order: nextOrder,
    featured: true,
  });

  await addGalleryItemIfMissing({
    title: "Roof Wash — Two-Story Home",
    caption: "Low-pressure roof cleaning on a two-story home",
    category: "Roofs",
    imageMediaId: roofBeachHouse,
    order: nextOrder + 1,
    featured: false,
  });

  await addGalleryItemIfMissing({
    title: "Window Detail — Siding & Trim",
    caption: "Streak-free windows after an exterior cleaning",
    category: "Windows",
    imageMediaId: windowSiding,
    order: nextOrder + 2,
    featured: true,
  });

  await addGalleryItemIfMissing({
    title: "Window Detail — Bay Window",
    caption: "Clean bay window and stone siding detail",
    category: "Windows",
    imageMediaId: windowBay,
    order: nextOrder + 3,
    featured: false,
  });

  console.log("");

  const placeholderTestimonials = [
    {
      customerName: "Placeholder Customer",
      testimonialText:
        "This is placeholder testimonial content. Replace it with a real customer review from the admin Testimonials page.",
      rating: 5,
      order: 3,
    },
    {
      customerName: "Placeholder Customer",
      testimonialText:
        "This is placeholder testimonial content. Replace it with a real customer review from the admin Testimonials page.",
      rating: 4,
      order: 4,
    },
  ];

  for (const t of placeholderTestimonials) {
    await addTestimonialIfMissing(t.customerName, t);
  }

  console.log("");

  // Placeholder service plan tiers. No prices are invented — priceLabel is
  // free text defaulting to "Contact for Pricing" until real pricing is
  // provided; everything here is editable from the admin Service Plans page.
  await addServicePlanIfMissing({
    name: "Seasonal Refresh",
    tagline: "A single deep clean to reset your property's curb appeal.",
    frequency: "One-Time",
    features: ["House or roof soft-wash", "Driveway & walkway cleaning", "Free follow-up quote for future visits"],
    priceLabel: "Contact for Pricing",
    highlighted: false,
    order: 0,
  });

  await addServicePlanIfMissing({
    name: "Maintenance Plan",
    tagline: "Recurring cleanings to keep your property looking its best year-round.",
    frequency: "Quarterly",
    features: ["House wash", "Driveway & walkway cleaning", "Window exterior rinse", "Priority scheduling"],
    priceLabel: "Contact for Pricing",
    highlighted: true,
    order: 1,
  });

  await addServicePlanIfMissing({
    name: "Complete Care Plan",
    tagline: "Comprehensive coverage for every exterior surface, twice a year.",
    frequency: "Twice a Year",
    features: ["House wash", "Roof soft-wash", "Driveway & walkway cleaning", "Window exterior cleaning", "Priority scheduling"],
    priceLabel: "Contact for Pricing",
    highlighted: false,
    order: 2,
  });

  console.log("");

  await upsertPageIfMissing(
    "service-plans",
    {
      heading: "Service Plans",
      intro:
        "Recurring maintenance plans to keep your property looking its best year-round. Pricing is customized per property — contact us for a personalized quote.",
    },
    {
      title: "Service Plans | LR Pressure Washing",
      metaDescription: "Recurring maintenance plans from LR Pressure Washing to keep your property looking its best year-round.",
    }
  );

  await upsertPageIfMissing(
    "reviews",
    {
      heading: "Customer Reviews",
      intro: "See what our customers have to say about our work.",
    },
    {
      title: "Reviews | LR Pressure Washing",
      metaDescription: "Read customer reviews for LR Pressure Washing.",
    }
  );

  await upsertPageIfMissing(
    "gallery",
    {
      heading: "Our Work",
      intro: "A look at recent projects across our service area.",
    },
    {
      title: "Gallery | LR Pressure Washing",
      metaDescription: "Browse photos of recent LR Pressure Washing projects.",
    }
  );

  console.log("");

  // Confirmed-real additional services (client confirmed LR performs these).
  await addServiceIfMissing({
    name: "Interior Window Cleaning",
    slug: "interior-window-cleaning",
    shortDescription: "Streak-free cleaning for the inside of your windows.",
    description:
      "In addition to exterior window cleaning, we offer interior window cleaning to get a truly streak-free, spotless finish on both sides of the glass.",
    icon: "AppWindow",
    order: 7,
  });

  await addServiceIfMissing({
    name: "Screen Cleaning",
    slug: "screen-cleaning",
    shortDescription: "Removing built-up dust and grime from window screens.",
    description:
      "Window screens collect dust, pollen, and grime that regular cleaning misses. We remove, clean, and reinstall your screens so they look as clear as your freshly cleaned windows.",
    icon: "Droplets",
    order: 8,
  });

  await addServiceIfMissing({
    name: "Christmas Light Installation",
    slug: "christmas-light-installation",
    shortDescription: "Professional holiday light installation and takedown.",
    description:
      "We install and take down holiday lighting for your home, so you can enjoy the season without climbing a ladder. Contact us to discuss your property and lighting plan.",
    icon: "PartyPopper",
    order: 9,
  });

  console.log("");

  await addNavItemIfMissing({ label: "Service Plans", href: "/service-plans" });
  await addNavItemIfMissing({ label: "Reviews", href: "/reviews" });
  await addNavItemIfMissing({ label: "Gallery", href: "/gallery" });

  console.log("\nDone. Refresh the site to see the additional content.");
  await mongoose.disconnect();
  process.exit(0);
}

main().catch((err) => {
  console.error("Failed to add content:", err);
  process.exit(1);
});
